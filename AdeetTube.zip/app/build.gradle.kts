plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.adshield.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.adshield.app"
        minSdk = 24; targetSdk = 34
        versionCode = 1; versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
