package com.adshield.app

import android.animation.*
import android.annotation.SuppressLint
import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.view.animation.*
import android.webkit.*
import android.widget.*
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.*
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var bar: ProgressBar
    private lateinit var fab: TextView
    private lateinit var welcome: FrameLayout
    private var spin: ObjectAnimator? = null
    private var ready = false
    private var guest = false

    private val blocked = listOf("doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com", "criteo.com",
        "amazon-adsystem.com", "moatads.com", "adsrvr.org", "popads.net")

    // Hides ad blocks and skips video ads inside the YouTube page
    private val js = """
    (function(){ if(window.__as) return; window.__as=1;
      var s=document.createElement('style');
      s.textContent='#masthead-ad,#player-ads,ytd-ad-slot-renderer,ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,.ytp-ad-overlay-container,.ad-container,ytm-statement-banner-renderer{display:none!important}';
      document.documentElement.appendChild(s);
      setInterval(function(){
        var p=document.querySelector('#movie_player,.html5-video-player');
        if(!p||!p.classList.contains('ad-showing')) return;
        var b=document.querySelector('.ytp-skip-ad-button,.ytp-ad-skip-button,.ytp-ad-skip-button-modern');
        if(b) b.click();
        var v=document.querySelector('video');
        if(v&&isFinite(v.duration)){v.muted=true;v.playbackRate=16;v.currentTime=v.duration;}
      },250);
    })();
    """

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun pill(fill: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(30).toFloat(); setColor(fill); if (stroke != 0) setStroke(dp(2), stroke)
    }
    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF0F0C29.toInt()
        root = FrameLayout(this)
        setContentView(root)
        setupWeb()
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(0xFFFF0033.toInt()); visibility = View.GONE
        }
        fab = label("⬇", 26f, Color.WHITE).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFF0033.toInt()) }
            elevation = dp(8).toFloat(); visibility = View.GONE
            setOnClickListener { download() }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(4), Gravity.TOP))
        root.addView(fab, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, dp(20), dp(90)) })
        welcome = buildWelcome()
        root.addView(welcome, FrameLayout.LayoutParams(-1, -1))

        Thread {
            try { YoutubeDL.getInstance().init(application); FFmpeg.getInstance().init(application); ready = true }
            catch (e: Exception) { }
        }.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb() {
        web = WebView(this)
        web.visibility = View.GONE
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString(); val h = r.url.host ?: ""
                if (blocked.any { h.endsWith(it) } || u.contains("/pagead/") ||
                    u.contains("/api/stats/ads") || u.contains("/ptracking"))
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                return null
            }
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) { bar.visibility = View.VISIBLE }
            override fun onPageFinished(v: WebView, url: String) {
                v.evaluateJavascript(js, null); bar.visibility = View.GONE
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { bar.progress = p }
        }
    }

    private fun buildWelcome(): FrameLayout {
        val w = FrameLayout(this)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt()))
        w.background = bg
        ValueAnimator.ofObject(ArgbEvaluator(), 0xFF302B63.toInt(), 0xFFB91D73.toInt()).apply {
            duration = 4000; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { bg.colors = intArrayOf(0xFF0F0C29.toInt(), it.animatedValue as Int) }
        }.start()

        val dm = resources.displayMetrics
        intArrayOf(0x55FF512F, 0x55DD2476, 0x5500C6FF, 0x55F7971E, 0x55A18CFF, 0x5500E5A8).forEach { c ->
            val s = dp(60 + (Math.random() * 90).toInt())
            val o = View(this)
            o.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
            w.addView(o, FrameLayout.LayoutParams(s, s).apply {
                leftMargin = (Math.random() * dm.widthPixels).toInt(); topMargin = (Math.random() * dm.heightPixels).toInt()
            })
            for (prop in listOf("translationX", "translationY")) {
                ObjectAnimator.ofFloat(o, prop, -dp(50).toFloat(), dp(50).toFloat()).apply {
                    duration = 3000 + (Math.random() * 3000).toLong()
                    repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
                    interpolator = AccelerateDecelerateInterpolator(); start()
                }
            }
        }

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(32), 0, dp(32), 0) }
        val logo = label("🛡️", 76f, Color.WHITE)
        val title = label("Adeet Tube", 38f, Color.WHITE, true)
        val sub = label("YouTube • No ads • Max quality", 15f, 0xCCFFFFFF.toInt())
        val g = label("G   Sign in with Google", 17f, 0xFF202124.toInt(), true).apply {
            background = pill(Color.WHITE); setPadding(dp(24), dp(16), dp(24), dp(16)) }
        val gu = label("Continue as Guest", 17f, Color.WHITE, true).apply {
            background = pill(0x22FFFFFF, Color.WHITE); setPadding(dp(24), dp(16), dp(24), dp(16)) }
        val lp = { top: Int -> LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) } }
        listOf(logo to 0, title to 8, sub to 6, g to 48, gu to 14).forEachIndexed { i, (v, t) ->
            col.addView(v, lp(t))
            v.alpha = 0f; v.translationY = dp(60).toFloat()
            v.animate().alpha(1f).translationY(0f).setStartDelay(300L + i * 160).setDuration(700)
                .setInterpolator(OvershootInterpolator(1.4f)).start()
        }
        ObjectAnimator.ofPropertyValuesHolder(logo,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.2f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.2f),
            PropertyValuesHolder.ofFloat("rotation", -8f, 8f)).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }
        ObjectAnimator.ofPropertyValuesHolder(g,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.05f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.05f)).apply {
            duration = 900; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }

        g.setOnClickListener { enter("https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fm.youtube.com%2F", false) }
        gu.setOnClickListener { enter("https://m.youtube.com", true) }
        w.addView(col, FrameLayout.LayoutParams(-1, -1))
        return w
    }

    private fun enter(url: String, g: Boolean) {
        guest = g
        if (g) CookieManager.getInstance().removeAllCookies(null)
        web.alpha = 0f; web.visibility = View.VISIBLE
        web.loadUrl(url)
        web.animate().alpha(1f).setDuration(700).start()
        welcome.animate().alpha(0f).scaleX(1.4f).scaleY(1.4f).setDuration(600)
            .withEndAction { root.removeView(welcome) }.start()
        fab.visibility = View.VISIBLE; fab.scaleX = 0f; fab.scaleY = 0f
        fab.animate().scaleX(1f).scaleY(1f).setStartDelay(900).setInterpolator(OvershootInterpolator(2.5f)).start()
        ObjectAnimator.ofFloat(fab, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 900; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE; start() }
    }

    private fun download() {
        val url = web.url ?: return
        if (!url.contains("watch") && !url.contains("/shorts/")) { toast("Open a video first"); return }
        if (!ready) { toast("Downloader is still starting, try again in a moment"); return }
        toast("Downloading best quality…")
        spin = ObjectAnimator.ofFloat(fab, "rotation", 0f, 360f).apply {
            duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); start() }
        val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)!!.absolutePath
        Thread {
            val msg = try {
                val r = YoutubeDLRequest(url)
                r.addOption("--no-playlist"); r.addOption("-f", "bv*+ba/b")
                r.addOption("--merge-output-format", "mkv"); r.addOption("-o", "$dir/%(title)s.%(ext)s")
                YoutubeDL.getInstance().execute(r, callback = { p, _, _ ->
                    runOnUiThread { bar.visibility = View.VISIBLE; bar.progress = p.toInt() } })
                "Saved to $dir"
            } catch (e: Exception) { "Failed: ${e.message?.take(80)}" }
            runOnUiThread { spin?.cancel(); fab.rotation = 0f; bar.visibility = View.GONE; toast(msg) }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (guest) CookieManager.getInstance().removeAllCookies(null); super.onDestroy() }
}
