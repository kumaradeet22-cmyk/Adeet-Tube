PHONE STEPS
1. Extract this zip in your Files app.
2. GitHub repo -> Add file -> Upload files -> upload everything inside the extracted folder (keep the app folder structure).
3. The .github folder is hidden on phones. If it did not upload:
   Add file -> Create new file -> name it:  .github/workflows/build.yml
   Open build.yml (included here, visible) and paste its text in. Commit.
4. Actions tab -> Build APK -> wait for the green tick -> download AdeetTube-apk under Artifacts.
